INSERT INTO users (first_name, last_name, email)
VALUES('Uchenna', 'Amadasun', 'uchenna@dojo.com'), ('Christian', 'Amadasun', 'christian@dojo.com');
SELECT * FROM users;