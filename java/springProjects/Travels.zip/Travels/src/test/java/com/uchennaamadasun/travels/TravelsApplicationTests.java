package com.uchennaamadasun.travels;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelsApplicationTests {

	@Test
	void contextLoads() {
	}

}
