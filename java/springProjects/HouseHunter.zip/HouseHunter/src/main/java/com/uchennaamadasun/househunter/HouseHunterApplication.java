package com.uchennaamadasun.househunter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HouseHunterApplication {

	public static void main(String[] args) {
		SpringApplication.run(HouseHunterApplication.class, args);
	}

}
