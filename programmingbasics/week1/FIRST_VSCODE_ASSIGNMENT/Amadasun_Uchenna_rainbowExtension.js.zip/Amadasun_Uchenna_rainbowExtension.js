console.log("I got a rainbow!")
console.log("And an extension called OPEN IN BROWSER")