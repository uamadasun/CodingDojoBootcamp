
//rider needs to be over 42 inches tall so we need a height variable
var height = 42;

//app needs age variable since the rider has to be over a certain age
var age = 10;

if (height > 52) {
    console.log("Get on that ride, kiddo!")
} 
else {
    console.log("Sorry kiddo. Maybe next year.")
}