import React, { useEffect, useState } from 'react'
import ProductForm from '../components/ProductForm';

const Main = () => {
    
    return(
        <div>
            <ProductForm/>
        </div>
    )
}
export default Main;