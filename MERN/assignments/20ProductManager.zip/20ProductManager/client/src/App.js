import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Main from './views/Main';

function App() {
  return (
    <div className="App">
      <Main/>
    </div>
  );
}

export default App;
